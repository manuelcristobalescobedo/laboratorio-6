// type User = {
//     username: string
//     loginDate: Date
//     mail: string
// }

// export type { User };

type Tarea = {
  numero: number
  nombre: string
  estado: boolean
}

export type { Tarea }
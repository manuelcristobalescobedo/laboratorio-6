import Formulario from "./Formulario"

export default function NuevaTarea() {
    return (
        <div>
            <h1>Página de nueva tarea</h1>
            <Formulario />
        </div>
    )
}
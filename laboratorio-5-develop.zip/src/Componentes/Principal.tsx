export default function Principal() {
    return <h1>¡Haz click en Tareas para ver tu lista de tareas<br /> o en Nueva tarea para agregar una!</h1>
}